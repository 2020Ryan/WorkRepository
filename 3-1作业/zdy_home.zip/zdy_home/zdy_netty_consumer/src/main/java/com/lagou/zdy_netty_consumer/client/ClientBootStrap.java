package com.lagou.zdy_netty_consumer.client;

import com.lagou.zdy_netty_common.UserService;

public class ClientBootStrap {

    public static void main(String[] args) throws InterruptedException {
        RpcConsumer rpcConsumer = new RpcConsumer();
        UserService proxy = (UserService)rpcConsumer.createProxy(UserService.class);

        while (true){
            Thread.sleep(2000);
            String result = proxy.sayHello("hello world!!!");


            System.out.println("consumer响应结果===>"+result);
        }
    }
}
