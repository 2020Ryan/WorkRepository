package com.lagou.zdy_netty_consumer.client;

import com.lagou.zdy_netty_common.JSONSerializer;
import com.lagou.zdy_netty_common.RpcEncoder;
import com.lagou.zdy_netty_common.RpcRequest;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoop;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.string.StringDecoder;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RpcConsumer {

    //创建线程池对象,根据cpu调度创建
    private  static ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    private  static UserClientHandler userClientHandler;

    //1、创建代理对象provider 组成：UserService#sayHello world!
    public  Object createProxy(final Class<?> serviceClass){
        //jdk动态代理生成
        return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class<?>[]{serviceClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                //（1）首先调用初始化netty客户端的方法
                if(userClientHandler == null){
                    initClient();
                }
                //（2）将参数获取封装
                RpcRequest request = new RpcRequest();
                String requestId = UUID.randomUUID().toString();

                System.out.println("requestId---->"+requestId);

                String className = method.getDeclaringClass().getName();
                String methodName = method.getName();
                //参数类型
                Class<?>[] parameterTypes = method.getParameterTypes();
                request.setRequestId(requestId);
                request.setClassName(className);
                request.setMethodName(methodName);
                request.setParameterTypes(parameterTypes);
                request.setParameters(args);

                //将参数赋值
                userClientHandler.setPara(request);

                return executorService.submit(userClientHandler).get();
            }
        });
    }

    /**
     * 初始化netty
     */
    public static void initClient() throws InterruptedException {
        userClientHandler = new UserClientHandler();
        //创建线程池
        EventLoopGroup group = new NioEventLoopGroup();

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group)
                //设置通道为NIO
                .channel(NioSocketChannel.class)
                //设定协议
                .option(ChannelOption.TCP_NODELAY,true)
                //设置监听
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel socketChannel) throws Exception {
                        //创建管道
                        ChannelPipeline pipeline =socketChannel.pipeline();
                        //设置编码
                        pipeline.addLast(new RpcEncoder(RpcRequest.class,new JSONSerializer()));
                        pipeline.addLast(new StringDecoder());
                        pipeline.addLast(userClientHandler);
                    }
                });
        bootstrap.connect("127.0.0.1",8990).sync();


    }

}
