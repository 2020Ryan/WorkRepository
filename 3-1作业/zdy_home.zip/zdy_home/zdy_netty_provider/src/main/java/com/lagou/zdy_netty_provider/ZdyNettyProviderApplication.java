package com.lagou.zdy_netty_provider;

import com.lagou.zdy_netty_provider.service.UserServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZdyNettyProviderApplication {

    public static void main(String[] args) throws InterruptedException {

        SpringApplication.run(ZdyNettyProviderApplication.class, args);
        UserServiceImpl.startServer("127.0.0.1",8990);
    }

}
