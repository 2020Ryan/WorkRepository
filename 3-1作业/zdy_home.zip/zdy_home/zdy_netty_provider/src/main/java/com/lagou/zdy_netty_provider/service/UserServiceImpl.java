package com.lagou.zdy_netty_provider.service;

import com.lagou.zdy_netty_common.JSONSerializer;
import com.lagou.zdy_netty_common.RpcDecoder;
import com.lagou.zdy_netty_common.RpcRequest;
import com.lagou.zdy_netty_common.UserService;
import com.lagou.zdy_netty_provider.handler.UserServerHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.string.StringEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {


    public String sayHello(String word) {
        System.out.println("provider方法调用成功--参数 "+word);
        return "provider方法调用成功--参数 "+word;
    }

    /**
     *
     * @param hostName ip地址
     * @param port     端口号
     */
    public static void startServer(String hostName,int port) throws InterruptedException {
        //创建俩个EventLoopGroup
        //处理接收请求
        NioEventLoopGroup bossGrop = new NioEventLoopGroup();
        //处理业务逻辑
        NioEventLoopGroup workGrop = new NioEventLoopGroup();
        //负责启动前的准备
        ServerBootstrap serverBootstrap = new ServerBootstrap();
        //开始初始化
        serverBootstrap.group(bossGrop,workGrop)
                //nio模型管道模型为nio
                .channel(NioServerSocketChannel.class)
                //选择SocketChannel去初始化
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel socketChannel) throws Exception {
                        ChannelPipeline pipeline = socketChannel.pipeline();
                        //对最后一个管道的位置添加编码解码
                        pipeline.addLast(new StringEncoder());
                        pipeline.addLast(new RpcDecoder(RpcRequest.class,new JSONSerializer()));
                        pipeline.addLast(new UserServerHandler());
                    }
                });
        //启动异步执行
        serverBootstrap.bind(hostName,port).sync();
        System.out.println("provider服务启动");

    }
}
