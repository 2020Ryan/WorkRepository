package com.lagou.zdy_netty_common;

public interface UserService {

    public String sayHello(String word);
}
